create function addnum(x int, y int)
  returns int
  BEGIN
	return (x+y);
    END;

