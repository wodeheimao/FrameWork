create procedure stu_delete(IN p_stuid int, OUT msg varchar(50))
  BEGIN
	declare n int default 0;
	select count(*) into n from t_student where stuid = p_stuid;
	if n = 1 then 
	delete from t_student where stuid = p_stuid;
	set msg = '删除成功';
	select msg;
	else 
	SET msg = '查不到';
	SELECT msg;	
	end if;
    END;

