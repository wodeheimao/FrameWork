create procedure allstu_select()
  BEGIN
	select * from t_student;
    END;

