create procedure tran_money(IN p_uid1 int, IN p_uid2 int, IN p_money double, OUT msg varchar(30))
  BEGIN
	declare n int default 0;
	declare continue handler for sqlexception set n = 1;
	update bank_money set u_money = u_money+p_money where uid = p_uid1;
	UPDATE bank_money SET u_money = u_money-p_money WHERE uid = p_uid2;
	if n=0 then
	set msg = '转账成功';
	commit;
	else
	set msg = '转账失败';
	rollback;
	end if;
	select msg;
    END;

