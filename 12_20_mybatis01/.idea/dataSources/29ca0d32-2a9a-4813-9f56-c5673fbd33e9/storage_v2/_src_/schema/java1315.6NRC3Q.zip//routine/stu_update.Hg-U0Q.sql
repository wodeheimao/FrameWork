create procedure stu_update(IN  p_stuid int, IN p_stuname varchar(20), IN p_stupwd varchar(10), IN p_stuage int,
                            OUT msg     varchar(50))
  BEGIN
	declare n int default 0;
	select count(*) into n from t_student where stuid = p_stuid;
	if n = 1 then 
	update t_student set stuname = p_stuname, stupwd = p_stupwd, stuage = p_stuage where stuid = p_stuid;
	set msg = '更新成功成功';
	select msg;
	else 
	SET msg = '查不到';
	SELECT msg;	
	end if;
    END;

