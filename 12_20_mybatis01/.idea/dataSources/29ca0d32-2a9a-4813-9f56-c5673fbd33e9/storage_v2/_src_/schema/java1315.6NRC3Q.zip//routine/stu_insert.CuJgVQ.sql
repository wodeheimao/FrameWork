create procedure stu_insert(IN p_stuname varchar(20), IN p_stupwd varchar(10), IN p_stuage int(4), OUT msg varchar(40))
  BEGIN
	insert into t_student (stuname,stupwd,stuage) values (p_stuname,p_stupwd,p_stuage);
	set msg = '插入成功';
	select msg;
    END;

