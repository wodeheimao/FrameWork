create view view_su as (select
                          `java1315`.`t_student`.`stuid`   AS `stuid`,
                          `java1315`.`t_student`.`stuname` AS `stuname`,
                          `java1315`.`t_student`.`stuage`  AS `stuage`
                        from `java1315`.`t_student`);

